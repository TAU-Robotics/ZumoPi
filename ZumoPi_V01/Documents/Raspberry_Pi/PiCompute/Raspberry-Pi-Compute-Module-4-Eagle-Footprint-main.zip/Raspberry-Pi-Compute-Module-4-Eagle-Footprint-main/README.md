# Raspberry-Pi-Compute-Module-4-Eagle-Footprint
New Raspberry Pi Compute Module 4 Eagle Library and 3D Models

Visit for tutorial https://www.youtube.com/channel/UC2l5Da1vBlsudKqLMDu_jPQ


![image](https://user-images.githubusercontent.com/28555587/99907881-6ce58680-2d05-11eb-9c88-b88c916436f8.png)
